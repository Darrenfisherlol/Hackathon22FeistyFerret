1
const { Client } = require("@hashgraph/sdk");
2
require("dotenv").config();
3
​
4
async function main() {
5
​
6
    //Grab your Hedera testnet account ID and private key from your .env file
7
    const myAccountId = process.env.MY_ACCOUNT_ID;
8
    const myPrivateKey = process.env.MY_PRIVATE_KEY;
9
​
10
    // If we weren't able to grab it, we should throw a new error
11
    if (myAccountId == null ||
12
        myPrivateKey == null ) {
13
        throw new Error("Environment variables myAccountId and myPrivateKey must be present");
14
    }
15
​
16
    // Create our connection to the Hedera network
17
    // The Hedera JS SDK makes this really easy!
18
    const client = Client.forTestnet();
19
​
20
    client.setOperator(myAccountId, myPrivateKey);
21
}
22
main();